import Loginsignup from "./Components/Loginsinup/Loginsinup";
function App() {
  return (
    <div className={Loginsignup}>
      <Loginsignup/>
    </div>
  );
}

export default App;
